﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Avatar2
{
    public class CameraConfiguration : ScriptableObject
    {


    }
}